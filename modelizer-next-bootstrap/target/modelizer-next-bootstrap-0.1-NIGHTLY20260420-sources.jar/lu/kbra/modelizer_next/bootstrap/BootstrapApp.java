package lu.kbra.modelizer_next.bootstrap;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Objects;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class BootstrapApp {

	private static final ObjectMapper MAPPER = new ObjectMapper();
	private static final String APP_DIR_PROPERTY = "APP_DIR";
	private static final String ENABLE_UPDATE_PROPERTY = "enableUpdate";
	private static final String APP_FOLDER_NAME = "modelizer-next";

	public static JsonNode JSON;
	public static String NAME;
	public static String VERSION;
	public static String REPOSITORY_URL;
	public static String RELEASES_URL;
	public static String UPDATES_MANIFEST_URL;

	private BootstrapApp() {
	}

	public static void init() throws IOException {
		final byte[] bytes = Objects.requireNonNull(BootstrapApp.class.getResourceAsStream("/app.json"), "Missing /app.json").readAllBytes();
		JSON = MAPPER.readTree(new String(bytes, StandardCharsets.UTF_8));
		NAME = JSON.path("name").asText("Modelizer Next Bootstrap");
		VERSION = JSON.path("version").asText("0.0.0");
		REPOSITORY_URL = JSON.path("repository").asText("https://github.com/UnKabaraQuiDev/modelizer-next");
		RELEASES_URL = JSON.path("releases").asText(REPOSITORY_URL + "/releases");
		UPDATES_MANIFEST_URL = JSON.path("updatesManifest").asText(REPOSITORY_URL + "/raw/main/versions.json");
		ensureDirectories();
	}

	public static boolean isAutomaticUpdateEnabled() {
		return Boolean.parseBoolean(System.getProperty(ENABLE_UPDATE_PROPERTY, "true"));
	}

	public static File getHomeDirectory() {
		final String override = System.getProperty(APP_DIR_PROPERTY);
		if (override != null && !override.isBlank()) {
			return new File(override);
		}

		final String os = System.getProperty("os.name", "").toLowerCase();
		if (os.contains("win")) {
			final String appData = System.getenv("APPDATA");
			if (appData != null && !appData.isBlank()) {
				return new File(appData, APP_FOLDER_NAME);
			}
		}
		return new File(System.getProperty("user.home"), "." + APP_FOLDER_NAME);
	}

	public static File getApplicationsDirectory() {
		return new File(getHomeDirectory(), "applications");
	}

	public static File getTempDirectory() {
		return new File(getHomeDirectory(), "updates");
	}

	public static File getBootstrapConfigFile() {
		return new File(getHomeDirectory(), "bootstrap-config.json");
	}

	public static void ensureDirectories() throws IOException {
		Files.createDirectories(getHomeDirectory().toPath());
		Files.createDirectories(getApplicationsDirectory().toPath());
		Files.createDirectories(getTempDirectory().toPath());
	}

	public static BootstrapConfiguration loadConfiguration() {
		final File file = getBootstrapConfigFile();
		if (!file.isFile()) {
			final BootstrapConfiguration configuration = new BootstrapConfiguration();
			saveConfiguration(configuration);
			return configuration;
		}
		try {
			return MAPPER.readValue(file, BootstrapConfiguration.class);
		} catch (final IOException ex) {
			return new BootstrapConfiguration();
		}
	}

	public static void saveConfiguration(final BootstrapConfiguration configuration) {
		try {
			ensureDirectories();
			MAPPER.writerWithDefaultPrettyPrinter().writeValue(getBootstrapConfigFile(), configuration);
		} catch (final IOException ex) {
			ex.printStackTrace();
		}
	}
}
