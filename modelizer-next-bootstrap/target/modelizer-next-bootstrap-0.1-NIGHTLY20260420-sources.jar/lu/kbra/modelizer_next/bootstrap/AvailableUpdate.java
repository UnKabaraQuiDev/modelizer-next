package lu.kbra.modelizer_next.bootstrap;

import java.net.URI;

public record AvailableUpdate(UpdateChannel channel, String currentVersion, String latestVersion, String notes, URI downloadUri,
		URI releasePageUri) {

	public boolean isUpdateAvailable() {
		return this.latestVersion != null && !this.latestVersion.isBlank() && !this.latestVersion.equals(this.currentVersion)
				&& this.downloadUri != null;
	}
}
